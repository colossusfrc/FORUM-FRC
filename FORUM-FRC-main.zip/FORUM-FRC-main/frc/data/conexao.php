<?php 
$host = 'localhost';
$dbname = "rookie";
$username = "root";
$password = '123';  

$conexao= mysqli_connect($host, $username, $password, $dbname);

session_start();

?>